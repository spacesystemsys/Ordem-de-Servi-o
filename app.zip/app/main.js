const { app, BrowserWindow } = require("electron");

app.on("ready", () => {
    console.log("Aplicação Iniciada");

    let mainWindow = new BrowserWindow({
        minWidth: 900,
        minHeight: 700,
        width: 900,
        height: 700
    });

    mainWindow.loadURL(`file://${__dirname}/app/index.html`);
});

app.on("window-all-closed", () => {
    app.quit();
});